
<?php

class WorkShiftRotary extends PluginWorkShiftRotary {
}
