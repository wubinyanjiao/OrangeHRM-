<?php
class WorkRotaryEmplayee extends PluginWorkRotaryEmplayee {
}
