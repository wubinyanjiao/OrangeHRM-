<?php

/**
 * @package    orangehrm
 * @subpackage model\pim
 */
class WorkTypeSkill extends PluginWorkTypeSkill {
}
